%_________________________________________________________________________
%  Adaptive Chaotic Marine Predators Hill Climbing Algorithm for Large-scale Design Optimisations (Developed in MATLAB R2020b)
%
%  
% paper:
%  A. A. Dehkordi, B. Etaati, M. Neshat and S. Mirjalili, 
%  Adaptive Chaotic Marine Predators Hill Climbing Algorithm for Large-scale Design Optimisations
%  IEEE Access
%  DOI: 10.1109/ACCESS.2023.3266991
%_________________________________________________________________________


clear 
clc
close all
format long
SearchAgents_no=50; % Number of search agents

Function_name='F1';
   
Max_iteration=2000; % Maximum number of iterations

[lb,ub,~,fobj]=Get_Functions_details(Function_name);
dim=300;

%% MPA
  [Best_score,Best_pos,Convergence_curve]= MPA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
%% HNMPA
  [Best_score1,Best_pos1,Convergence_curve1]= HNMPA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
%% HNCMPA
  [Best_score2,Best_pos2,Convergence_curve2]= HNCMPA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);

figure;
semilogy(Convergence_curve,'Linewidth',2)
hold on
semilogy(Convergence_curve1,'Linewidth',2)
hold on
semilogy(Convergence_curve2,'Linewidth',2)
title('Objective space F1')
xlabel('Iteration');
ylabel('Best score obtained so far');
legend('MPA','MNMPA','MNCMPA');


